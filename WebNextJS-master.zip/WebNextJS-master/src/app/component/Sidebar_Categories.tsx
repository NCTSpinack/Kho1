import { PiTireFill } from "react-icons/pi";
import Image from "next/image";
import { FaChevronRight, FaProductHunt, FaLightbulb } from "react-icons/fa";

const categories = [
  { name: "All Products", count: 1 },
  { name: "Brakes", count: 5 },
  { name: "Electrical", count: 5 },
  { name: "Engine", count: 5 },
  { name: "Heating and Cooling", count: 5 },
  { name: "Steering", count: 4 },
  { name: "Suspension", count: 5 },
];
const CategoriesDMSP = [
  { name: "Lốp ô tô thanh lý" },
  { name: "Lốp ô tô mới" },
  { name: "Lốp ô tô cũ" },
  { name: "Bình ắc quy " },
  { name: "Cần gạt mưa" },
  { name: "Nước làm mát" },
  { name: "Dây câu bình" },
  { name: "Van cảm biến" },
  { name: "Van cao su" },
  { name: "Vành độ" },
  { name: "Sạc không dây" },
  { name: "Bơm lốp Michelin" },
];
export default function Sidebar_Categories() {
  return (
    <>
      <h2 className="text-xl font-semibold text-white mb-4 text-center bg-rose-700 rounded-4xl h-10 flex items-center justify-center">
        Tìm kiếm nhiều nhất
      </h2>
      <ul>
        {categories.map((category, index) => (
          <li
            key={index}
            className="flex items-center justify-between p-1 hover:bg-rose-700 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
                <PiTireFill className="text-rose-700 text-4xl " />
              </div>
              <span>{category.name}</span>
            </div>
            <span className="flex items-center justify-center w-12 h-12 bg-red-100 text-red-600 font-bold text-lg rounded-full">
              {category.count}
            </span>
          </li>
        ))}
      </ul>
      <hr className="border-1 border-gray-300 my-5" />
      <h2 className="text-xl font-semibold text-white mb-4 text-center bg-rose-700 rounded-4xl h-10 flex items-center justify-center">
        DANH MỤC SẢN PHẨM
      </h2>
      <ul>
        {CategoriesDMSP.map((categorydmsp, index) => (
          <li
            key={index}
            className="flex items-center justify-between p-1 hover:bg-rose-700 hover:text-amber-50 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300"
          >
            <div className="flex items-center gap-3 ">
              <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
                <FaProductHunt className="text-rose-700 text-4xl " />
              </div>
              <span>{categorydmsp.name}</span>
            </div>
          </li>
        ))}
      </ul>
      <hr className="border-1 border-gray-300 my-5" />
      <h2 className="text-xl font-semibold text-white mb-4 text-center bg-rose-700 rounded-4xl h-10 flex items-center justify-center">
        CÓ THỂ BẠN CẦN
      </h2>
      <ul>
        <li className="flex items-center justify-between p-1 hover:bg-rose-700 hover:text-amber-50 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300">
          <div className="flex items-center gap-3 ">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
              <FaLightbulb className="text-rose-700 text-4xl " />{" "}
            </div>
            <span>Cách tháo lốp dự phòng </span>
          </div>
        </li>
        <li className="flex items-center justify-between p-1 hover:bg-rose-700 hover:text-amber-50 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300">
          <div className="flex items-center gap-3 ">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
              <FaLightbulb className="text-rose-700 text-4xl " />
            </div>
            <span>Cách tháo ắc quy xe </span>
          </div>
        </li>
        <li className="flex items-center justify-between p-1 hover:bg-rose-700 hover:text-amber-50 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300">
          <div className="flex items-center gap-3 ">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
              <FaLightbulb className="text-rose-700 text-4xl " />
            </div>
            <span>Dấu hiệu cần thay ắc quy </span>
          </div>
        </li>
        <li className="flex items-center justify-between p-1 hover:bg-rose-700 hover:text-amber-50 rounded-lg mb-2 cursor-pointer border border-gray-300 transition duration-300">
          <div className="flex items-center gap-3 ">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex justify-center items-center">
              <FaLightbulb className="text-rose-700 text-4xl " />
            </div>
            <span>Các cảnh báo trên xe</span>
          </div>
        </li>
      </ul>
    </>
  );
}
