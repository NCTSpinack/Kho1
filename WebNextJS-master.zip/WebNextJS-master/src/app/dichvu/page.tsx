import ServiceGrid from "./ServiceGrid";

export default function DichVu(){
    return(
        <>
            <ServiceGrid/>
        </>
    )
}