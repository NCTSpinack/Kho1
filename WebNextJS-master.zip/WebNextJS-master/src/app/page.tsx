import Image from "next/image";
import Banner from "@/app/component/banner";
import DMSPTEST from "./component/dmsptest"
import TEST from "./component/TinTuc"
import Navbar from "./component/Navbar";
import Header from "./component/header";
export default function Home() {
  return (
   <>
      <Header/>
      <Navbar/>
      <Banner/>
      <DMSPTEST/>
      <TEST/>
   </>
  );
}
