"use client";
import React, { useState } from "react";
import { TextField, Autocomplete } from "@mui/material";

const optionsSize1 = [
  "155",
  "165",
  "175",
  "185",
  "195",
  "205",
  "215",
  "225",
  "235",
  "245",
  "255",
  "265",
  "275",
  "285",
  "295",
  "305",
];
const optionsSize2 = ["50", "55", "60", "65", "70", "75", "80"];
const optionsSize3 = [
  "R13",
  "R14",
  "R15",
  "R16",
  "R17",
  "R18",
  "R19",
  "R20",
  "R21",
  "R22",
];
export default function SeachSize({
  onSubmit,
}: {
  onSubmit: (data: any) => void;
}) {
  const [value1, setValue1] = useState<string | null>(null);
  const [value2, setValue2] = useState<string | null>(null);
  const [value3, setValue3] = useState<string | null>(null);

  const handleSubmit = () => {
    onSubmit({
      chieu_rong: value1,
      chieu_cao: value2,
      vanh_inch: value3,
      cancel: "NO",
    });
  };
  const handleSubmit_cancel = () => {
    setValue1(null);
    setValue2(null);
    setValue3(null);
    onSubmit({
      cancel: "YES",
    });
  };
  return (
   <>
  {/* Form chọn thông số lốp */}
  <div className="flex flex-col gap-4 p-2">
    <Autocomplete
      options={optionsSize1}
      value={value1}
      onChange={(event, newValue) => setValue1(newValue)}
      renderInput={(params) => (
        <TextField {...params} label="Chiều rộng" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />

    <Autocomplete
      options={optionsSize2}
      value={value2}
      onChange={(event, newValue2) => setValue2(newValue2)}
      renderInput={(params) => (
        <TextField {...params} label="Chiều cao" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />

    <Autocomplete
      options={optionsSize3}
      value={value3}
      onChange={(event, newValue3) => setValue3(newValue3)}
      renderInput={(params) => (
        <TextField {...params} label="Vành (Inch)" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />
  </div>

  {/* Nút hành động */}
  <div className="flex gap-3 mt-4">
    <button
      onClick={handleSubmit_cancel}
      className="w-1/2 bg-gray-200 text-gray-800 font-semibold py-2 rounded-lg shadow-sm hover:bg-gray-300 transition"
    >
      Xóa lọc
    </button>
    <button
      onClick={handleSubmit}
      className="w-1/2 bg-rose-600 text-white font-semibold py-2 rounded-lg shadow-sm hover:bg-rose-700 transition"
    >
      Tìm kiếm
    </button>
  </div>
</>

  );
}
