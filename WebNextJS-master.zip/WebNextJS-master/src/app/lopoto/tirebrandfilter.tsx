"use client";
import React, { useState } from "react";
import { TextField, Autocomplete } from "@mui/material";

const options_thuonghieu = [
  "Toàn bộ",
  "Michelin",
  "Bridgestone",
  "Kumho",
  "Sailun",
  "Atslas",
  "Continental",
  "Dunlop",
  "Caosumina",
];
const options_loailop = ["Toàn bộ", "Lốp mới", "Lốp thanh lý", "Lốp lướt"];

export default function AutoComplete_TireBrand_TypeTire({
  onSelectBrand,
}: {
  onSelectBrand: (thuong_hieu: string, loai_lop: string) => void;
}) {
  const [value1, setValue1] = useState(options_thuonghieu[0]);
  const [value2, setValue2] = useState(options_loailop[0]);

  // gọi về cha đúng kiểu 2 string
  const handleChange = (newBrand: string, newType: string) => {
    onSelectBrand(newBrand, newType);
  };

  return (
   <div className="flex flex-col sm:flex-row gap-2 w-full m-2">
  {/* Autocomplete Thương hiệu */}
  <Autocomplete
    options={options_thuonghieu}
    value={value1}
    onChange={(event, newValue) => {
      const brand = newValue ?? options_thuonghieu[0];
      setValue1(brand);
      handleChange(brand, value2);
    }}
    renderInput={(params) => (
      <TextField {...params} label="Thương hiệu" variant="outlined" />
    )}
    size="small"
    className="w-full sm:w-[200px] md:w-[250px]"
  />

  {/* Autocomplete Loại lốp */}
  <Autocomplete
    options={options_loailop}
    value={value2}
    onChange={(event, newValue2) => {
      const type = newValue2 ?? options_loailop[0];
      setValue2(type);
      handleChange(value1, type);
    }}
    renderInput={(params) => (
      <TextField {...params} label="Chọn loại lốp" variant="outlined" />
    )}
    size="small"
    className="w-full sm:w-[200px] md:w-[250px]"
  />
</div>

  );
}
