"use client";
import { useEffect, useState } from "react";
import AutoComplete_TireBrand_TypeTire from "./tirebrandfilter";
import ArrangeFiter from "./arrangefilter";
import Image from "next/image";
import SetActiveForm from "./setActiveForm";
import Link from "next/link";

const Lopoto = () => {
  const categories = [
    { name: "All Products", count: 1 },
    { name: "Brakes", count: 5 },
    { name: "Electrical", count: 5 },
    { name: "Engine", count: 5 },
    { name: "Heating and Cooling", count: 5 },
    { name: "Steering", count: 4 },
    { name: "Suspension", count: 5 },
  ];
  const CategoriesDMSP = [
    { name: "Lốp ô tô thanh lý" },
    { name: "Lốp ô tô mới" },
    { name: "Lốp ô tô cũ" },
    { name: "Bình ắc quy " },
    { name: "Cần gạt mưa" },
    { name: "Nước làm mát" },
    { name: "Dây câu bình" },
    { name: "Van cảm biến" },
    { name: "Van cao su" },
    { name: "Vành độ" },
    { name: "Sạc không dây" },
    { name: "Bơm lốp Michelin" },
  ];

  const productsPerPage = 8; // Số sản phẩm trên mỗi trang
  const [currentPage, setCurrentPage] = useState(1);
  const [products, setProducts] = useState<any[]>([]);
  const [originalProduct, setOriginalProduct] = useState<any[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch("/api/products/lopoto");
        const data = await res.json();
        console.log("lốp:", data);
        setProducts(data);
        setOriginalProduct(data);
      } catch (err) {
        console.error("Không thể tải sản phẩm:", err);
      }
    };

    fetchProducts();
  }, []);

  // Tính toán sản phẩm của trang hiện tại
  const startIndex = (currentPage - 1) * productsPerPage;
  const currentProducts = products.slice(
    startIndex,
    startIndex + productsPerPage
  );

  // Tính tổng số trang
  const totalPages = Math.ceil(products.length / productsPerPage);

  type Filters = {
    kich_thuoc: string | null;
    thuong_hieu: string | null;
    loai_lop: string | null;
    hang_xe: string | null;
    ten_xe: string | null;
    doi_xe: string | null;
  };

  // xử lý tìm kiếm
  const [filters, setFilters] = useState<Filters>({
    kich_thuoc: null,
    thuong_hieu: null,
    loai_lop: null,
    hang_xe: null,
    ten_xe: null,
    doi_xe: null,
  });

  const handleSearchData = async (data: any) => {
    if (data.cancel == "YES") {
      const newFilters = {
        ...filters,
        kich_thuoc: null,
        hang_xe: null,
        ten_xe: null,
        doi_xe: null,
      };
      setFilters(newFilters); // cập nhật state
      // lọc theo giá trị cũ đang chọn ở thương hiệu và loại lốp
      const res = await fetch("/api/products/lopoto/timkiem", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newFilters),
      });

      const result = await res.json();
      console.log("tìm theo xe:", result.data);
      setProducts(result.data);
    } else {
      if (data.flag == "true") {
        if (!data.hang_xe || !data.ten_xe || !data.doi_xe) {
          alert("hãng xe, tên xe, đời xe không được để trống!");
          return 0;
        } else {
          // setfillter để lưu trạng thái
          const newFilters = {
            ...filters,
            hang_xe: data.hang_xe,
            ten_xe: data.ten_xe,
            doi_xe: data.doi_xe,
            kich_thuoc: null, // reset kích thước khi tìm theo xe
          };

          setFilters(newFilters);
          // Gọi API tìm kiếm theo hãng xe, tên xe, đời xe
          const res = await fetch("/api/products/lopoto/timkiem", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(newFilters),
          });

          const result = await res.json();
          console.log("tìm theo xe:", result.data);
          setProducts(result.data);
        }
      } else {
        if (!data.chieu_rong || !data.chieu_cao || !data.vanh_inch) {
          alert("thông số lốp xe không được để trống!");
          return 0;
        }
        const kich_thuoc = `${data.chieu_rong}/${data.chieu_cao}${data.vanh_inch}`;

        const newFilters = {
          ...filters,
          kich_thuoc,
          hang_xe: null, // reset nhóm theo xe
          ten_xe: null,
          doi_xe: null,
        };
        setFilters(newFilters);
        // Gọi API tìm theo kích thước
        const res = await fetch("/api/products/lopoto/timkiem", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newFilters),
        });

        const result = await res.json();
        console.log("resul_Lop:", result.data);
        setProducts(result.data);
      }
    }
  };
  const handleFilterChange = async (thuong_hieu: string, loai_lop: string) => {
    const newFilters = {
      ...filters,
      thuong_hieu: thuong_hieu,
      loai_lop: loai_lop,
    };
    setFilters(newFilters);
    // Gọi API tìm theo thương hiệu và loại lốp
    const res = await fetch("/api/products/lopoto/timkiem", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newFilters),
    });

    const result = await res.json();
    console.log("resul_thuonghieu_loailop:", result.data);
    setProducts(result.data);
  };
  // console.log("Dữ liệu tìm kiếm OKI:", filters);

  return (
    <>
      <div className="container mx-auto w-11/12 py-10">
        <div className="grid grid-cols-12 gap-8">
          {/* Sidebar */}
          <SetActiveForm onSearch={handleSearchData} />

          {/* Content */}
          <main className="col-span-12 md:col-span-9 space-y-8">
            {/* Thanh filter trên cùng */}
            <div className="flex items-center justify-between bg-white border-1 border-gray-300 rounded-xl shadow-sm p-4  ">
              <div className="flex-1 flex gap-5">
                <AutoComplete_TireBrand_TypeTire
                  onSelectBrand={handleFilterChange}
                />
              </div>
              <div>{/* <ArrangeFiter /> */}</div>
            </div>

            {/* Danh sách sản phẩm */}
            <div className="bg-white border border-gray-200 rounded-xl shadow-md p-6">
              <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 uppercase">
                Danh sách sản phẩm
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                {currentProducts.map((p) => (
                  <div
                    key={p.id}
                    className="flex flex-col justify-between bg-white p-4 rounded-lg shadow-sm border border-gray-200 transition duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-rose-500"
                  >
                    <Link href={`/lopoto/${p.slug}`}>
                      <div className="relative">
                        <span className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded-md shadow">
                          {p.thong_so_lop[0].loai_lop.ten_loai_lop}
                        </span>
                        <Image
                          src={p.anh_dai_dien}
                          alt={p.ten_san_pham}
                          width={500}
                          height={500}
                          className="w-full h-40 rounded-lg object-contain bg-gray-50"
                          priority
                        />
                      </div>
                      <div className="mt-3 space-y-1">
                        <p className="text-yellow-500 text-sm font-medium">
                          ⭐ {p.rating} / 5
                        </p>
                        <h3 className="text-base font-semibold text-gray-800 leading-snug break-words">
                          {p.ten_san_pham}
                        </h3>
                        <p
                          className={`text-sm font-semibold ${
                            p.trang_thai ? "text-green-600" : "text-red-500"
                          }`}
                        >
                          {p.trang_thai ? "Còn hàng" : "Hết hàng"}
                        </p>
                      </div>
                      <button className="mt-3 w-full bg-rose-500 text-white py-2 rounded-lg font-medium shadow hover:bg-rose-600 transition duration-300">
                        Liên hệ ngay
                      </button>
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Pagination */}
            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className={`px-5 py-2 rounded-lg shadow text-white font-medium transition ${
                  currentPage === 1
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-rose-500 hover:bg-rose-600"
                }`}
              >
                Trang trước
              </button>

              <span className="text-lg font-semibold text-gray-700">
                Trang {currentPage} / {totalPages}
              </span>

              <button
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
                className={`px-5 py-2 rounded-lg shadow text-white font-medium transition ${
                  currentPage === totalPages
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-rose-500 hover:bg-rose-600"
                }`}
              >
                Trang sau
              </button>
            </div>
          </main>
        </div>
      </div>
    </>
  );
};

export default Lopoto;
