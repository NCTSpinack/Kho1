"use client";
import React, { useState } from "react";
import { TextField, Autocomplete } from "@mui/material";
const optionsCarBrand = [
  "Hyundai",
  "Toyota",
  "Honda",
  "Nissan",
  "Mazda",
  "Mitsubishi",
  "Subaru",
  "Volkswagen",
  "BMW",
  "Mercedes-Benz",
  "Audi",
  "Porsche",
  "Ford",
  "Chevrolet",
  "Tesla",
  "Jeep",
  "Dodge",
  "Kia",
  "Maserati",
  "Rolls-Royce",
  "Bentley",
  "Jaguar",
  "Land Rover",
  "Peugeot",
  "VinFast",
];
const optionsCarName = [
  "Grand i10",
  "Alphard",
  "Rush",
  "Wigo",
  "Avanza",
  "Land Cruiser Prado",
  "Hiace",
  "Granvia",
  "Trailblazer",
  "Colorado",
  "CX-5",
  "CX-8",
  "Mazda 3",
  "Mazda 6",
  "Kia Morning",
  "Kia Seltos",
  "Kia Sorento",
  "Kia Carnival",
  "Kia K3",
  "Kia K5",
  "Kia Sonet",
  "Mitsubishi Xpander",
  "Mitsubishi Outlander",
  "Mitsubishi Pajero Sport",
  "Nissan Navara",
  "Nissan Terra",
  "Subaru Forester",
  "Subaru Outback",
  "Mercedes-Benz C-Class",
  "Mercedes-Benz E-Class",
  "Mercedes-Benz GLC",
  "BMW 3 Series",
  "BMW 5 Series",
  "BMW X5",
  "Audi A4",
  "Audi Q5",
  "Lexus RX",
  "Lexus NX",
];
const optionsCarLife = [
  "2010",
  "2011",
  "2012",
  "2013",
  "2014",
  "2015",
  "2016",
  "2017",
  "2018",
  "2019",
  "2020",
  "2021",
  "2022",
  "2023",
  "2024",
  "2025",
];
export default function SeachType({
  onSubmit,
}: {
  onSubmit: (data: any) => void;
}) {
  const [value1, setValue1] = useState<string | null>(null);
  const [value2, setValue2] = useState<string | null>(null);
  const [value3, setValue3] = useState<string | null>(null);
  const handleSubmit = () => {
    onSubmit({
      hang_xe: value1,
      ten_xe: value2,
      doi_xe: value3,
      cancel: "NO",
      flag: "true"
    });
  };
  const CancelSeachs = () => {
    onSubmit({
      cancel: "YES",
    });
    setValue1(null);
    setValue2(null);
    setValue3(null)
  };

  return (
    <>
  {/* Form chọn xe */}
  <div className="flex flex-col gap-4 p-2">
    <Autocomplete
      options={optionsCarBrand}
      value={value1}
      onChange={(event, newValue) => setValue1(newValue)}
      renderInput={(params) => (
        <TextField {...params} label="Hãng xe" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />

    <Autocomplete
      options={optionsCarName}
      value={value2}
      onChange={(event, newValue2) => setValue2(newValue2)}
      renderInput={(params) => (
        <TextField {...params} label="Tên xe" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />

    <Autocomplete
      options={optionsCarLife}
      value={value3}
      onChange={(event, newValue3) => setValue3(newValue3)}
      renderInput={(params) => (
        <TextField {...params} label="Đời xe" variant="outlined" />
      )}
      size="small"
      className="w-full"
    />
  </div>

  {/* Nút hành động */}
  <div className="flex gap-3 mt-4">
    <button
      onClick={CancelSeachs}
      className="w-1/2 bg-gray-200 text-gray-800 font-semibold py-2 rounded-lg shadow-sm hover:bg-gray-300 transition"
    >
      Xóa bỏ
    </button>
    <button
      onClick={handleSubmit}
      className="w-1/2 bg-rose-600 text-white font-semibold py-2 rounded-lg shadow-sm hover:bg-rose-700 transition"
    >
      Tìm kiếm
    </button>
  </div>
</>

  );
}
