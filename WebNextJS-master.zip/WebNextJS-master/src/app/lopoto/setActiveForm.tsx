"use client";
import { FaFilter } from "react-icons/fa";
import { useState } from "react";
import SeachSize from "./SeachSize";
import SeachTypeCar from "./SeachType";
export default function SetActiveForm({ onSearch }: { onSearch: (data: any) => void }) {
  const [activeForm, setActiveForm] = useState<'tire' | 'car'>('tire');
  return (
    <>
     <aside className="col-span-12 md:col-span-3 bg-gradient-to-b from-gray-50 to-white shadow-md rounded-2xl p-6 border-2 border-rose-600">
  <h2 className="text-xl font-semibold text-center rounded-xl h-11 flex items-center justify-center">
    <FaFilter className="mr-3" />
    Tìm kiếm Lốp
  </h2>
  <hr className="border-1 border-gray-500 my-3" />

  <div className="flex">
    <button
      className={`w-1/2 py-2 border-r ${activeForm === "tire" ? "font-semibold text-rose-600" : ""}`}
      onClick={() => setActiveForm("tire")}
    >
      Lốp xe
    </button>
    <button
      className={`w-1/2 py-2 ${activeForm === "car" ? "font-semibold text-rose-600" : ""}`}
      onClick={() => setActiveForm("car")}
    >
      Theo dòng xe
    </button>
  </div>

  <div className="min-h-[200px] border border-gray-300 rounded p-3">
    <div className="flex flex-col gap-2">
      {activeForm === "tire" && <SeachSize onSubmit={onSearch} />}
      {activeForm === "car" && <SeachTypeCar onSubmit={onSearch} />}
    </div>
  </div>
</aside>

    </>
  );
}
