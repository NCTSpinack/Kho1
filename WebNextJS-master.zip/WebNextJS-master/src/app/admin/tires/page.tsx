export default function ProductPage() {
  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Danh sách sản phẩm</h1>
      <p>Hiển thị sản phẩm tại đây...</p>
    </div>
  );
}
