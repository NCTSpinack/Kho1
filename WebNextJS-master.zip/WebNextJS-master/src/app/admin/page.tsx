export default function AdminDashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Chào mừng đến Admin Dashboard</h1>
      <p>Đây là giao diện quản trị website của bạn.</p>
    </div>
  );
}
