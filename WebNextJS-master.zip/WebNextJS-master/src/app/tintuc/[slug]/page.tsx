import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import Image from "next/image";

interface PageProps {
  params: { slug: string };
}

export default async function PostDetail({ params }: PageProps) {
  const { slug } = params;
  const item = await db.tintuclopoto.findUnique({
    where: { slug },
  });

  if (!item) return notFound();

  return (
    <div className="container mx-auto  w-11/12 py-5">
      <div className="grid grid-cols-12 gap-8 ">
        {/* Sidebar */}
        <aside className="col-span-12 md:col-span-3 bg-gradient-to-b from-blue-50 to-white shadow-lg rounded-3xl p-6 h-full">
          <h2 className="text-xl font-bold mb-5 border-b pb-3 text-gray-900 text-center">
            Danh mục tin tức
          </h2>
          <ul className="space-y-3 text-gray-700">
            {[
              "Tin khuyến mãi",
              "Công nghệ ô tô",
              "Chia sẻ kinh nghiệm",
              "Tin tức thị trường",
            ].map((cat, idx) => (
              <li
                key={idx}
                className="hover:text-blue-600 hover:translate-x-2 transition-all cursor-pointer"
              >
                🔹 {cat}
              </li>
            ))}
          </ul>
        </aside>

        {/* Main Content */}
        <main className="col-span-12 md:col-span-9  px-4 py-5  bg-gradient-to-b from-blue-50 to-white rounded-3xl">
          {/* Header */}
          <header className="text-center mb-8">
            <h3 className="text-xs font-semibold text-gray-900 uppercase tracking-wider">
              Tin tức - Khuyến mãi
            </h3>
            <hr className="border-gray-500 w-36 mx-auto mt-2" />
          </header>

          {/* Bài viết */}
          <article className=" mx-auto space-y-5">
            <h1 className="text-3xl font-semibold text-center mb-10">
              {item.tieu_de}
            </h1>

            {/* Thông tin shop */}
            <div className="rounded-lg p-6  text-gray-800 ">
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold text-blue-800 mb-1">
                  Lốp ô tô Cảnh Thạch
                </h2>
                <p className="italic text-blue-800">
                  “Mua bán trao đổi lốp ô tô cũ đã qua sử dụng tại Hà Nội”
                </p>
              </div>
              <ul className="space-y-3 text-base md:text-lg">
                <li className="flex items-center gap-2">
                  <span className="font-semibold text-pink-600 text-lg md:text-xl">
                    📘 FACEBOOK:
                  </span>
                  <span className="text-gray-800">Lốp ô tô Cũ & Mới</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="font-semibold text-pink-600 text-lg md:text-xl">
                    📍 ĐỊA CHỈ:
                  </span>
                  <span className="text-gray-800">
                    Số 182, Đường Lê Trọng Tấn, Hà Đông, HN
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-gray-800">☎️ HOTLINE:</span>
                  <span className="font-bold text-pink-600 text-lg md:text-xl">
                    0349566377
                  </span>
                </li>
              </ul>
            </div>

            {/* Thông tin sản phẩm */}
            <div className="bg-gray-50 border border-gray-300 rounded-lg p-6 shadow-sm text-gray-700 space-y-4">
              <h2 className="text-3xl font-bold text-blue-800 text-center">
                Lốp 225/45R18 Bridgestone mới thanh lý giá rẻ
              </h2>
              <div>
                <h3 className="text-lg font-semibold mb-2">Giới thiệu:</h3>
                <p className="leading-relaxed">{item.tom_tat}</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  Thông tin lốp xe:
                </h3>
                <ul className="list-disc list-inside space-y-2">
                  {[
                    "Kích thước: 275/45R18",
                    "Thương hiệu: Bridgestone",
                    "Gai lốp: Alenza 700S",
                    "Sản xuất: 2022 Tại Thái Lan",
                    "Bảo hành: Chính hãng Bridgestone",
                  ].map((info, idx) => (
                    <li key={idx} className="flex items-center">
                      <input
                        type="checkbox"
                        checked
                        readOnly
                        className="mr-2 w-4 h-4 text-blue-600"
                      />
                      {info}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Hình ảnh */}
            <div className="relative w-full aspect-[3/2] rounded-lg overflow-hidden border border-gray-300 shadow-sm bg-white">
              <Image
                src={item.hinh_anh}
                alt={item.tieu_de}
                fill
                className="object-contain"
                sizes="(max-width: 768px) 100vw, 800px"
                priority
              />
            </div>
          </article>
        </main>
      </div>
    </div>
  );
}
