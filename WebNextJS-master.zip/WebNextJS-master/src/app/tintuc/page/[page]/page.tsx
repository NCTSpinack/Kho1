import { db } from "@/lib/db";
import Image from "next/image";
import Link from "next/link";

interface PageProps {
  params: { page: string };
}
const LIMIT = 6; // số tin mỗi trang

export default async function TinTucPage({ params }: PageProps) {
  const resolvedParams = await params;
  const pageNumber = parseInt(resolvedParams.page || "1");
  // 1. Tính tổng số tin
  const total = await db.tintuclopoto.count();
  const totalPages = Math.ceil(total / LIMIT);
  // 2. Lấy tin cho trang hiện tại
  const tinTuc = await db.tintuclopoto.findMany({
    skip: (pageNumber - 1) * LIMIT,
    take: LIMIT,
    orderBy: { ngay_dang: "desc" },
  });

  return (
    <>
      <div className="container mx-auto w-11/12 py-10">
        <div className="grid grid-cols-12 gap-8">
          {/* Sidebar */}
          <aside className="col-span-12 md:col-span-3 bg-gradient-to-b from-gray-50 to-white shadow-md rounded-2xl p-6 border-2">
            <h2 className="text-xl font-bold mb-5 text-gray-700 border-b pb-3">
              Danh mục tin tức
            </h2>
            <ul className="space-y-3 text-gray-600">
              <li className="hover:text-blue-600 cursor-pointer transition">
                🔹 Tin khuyến mãi
              </li>
              <li className="hover:text-blue-600 cursor-pointer transition">
                🔹 Công nghệ ô tô
              </li>
              <li className="hover:text-blue-600 cursor-pointer transition">
                🔹 Chia sẻ kinh nghiệm
              </li>
              <li className="hover:text-blue-600 cursor-pointer transition">
                🔹 Tin tức thị trường
              </li>
            </ul>
          </aside>

          <main className="col-span-12 md:col-span-9 grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {tinTuc.map((item: any) => (
              <Link key={item.id} href={`/tintuc/${item.slug}`}>
                <div className="bg-white rounded-2xl shadow-lg overflow-hidden group hover:shadow-2xl transition duration-300 ease-in-out border border-gray-100">
                  <div className="relative">
                    <Image
                      src={
                        item.hinh_anh
                      }
                      alt={item.tieu_de}
                      width={600}
                      height={400}
                      className="w-full h-52 object-cover transform group-hover:scale-105 transition duration-500 ease-in-out"
                      priority
                    />
                    {/* Ngày tháng */}
                    <div className="absolute top-4 left-4 bg-gradient-to-b from-blue-600 to-blue-500 text-white text-xs font-bold px-3 py-2 rounded-xl shadow-md">
                      <div className="text-lg leading-none">28</div>
                      <div className="uppercase tracking-wide">Th11</div>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-lg font-semibold text-gray-800 group-hover:text-blue-600 transition line-clamp-2">
                      {item.tieu_de}
                    </h3>
                    <p className="text-sm text-gray-500 mt-3 leading-relaxed line-clamp-3">
                      {item.tom_tat}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </main>
          <div className="col-span-12 md:col-span-9 flex gap-2 mt-4 justify-end">
            {Array.from({ length: totalPages }, (_, i) => (
              <Link
                key={i}
                href={`/tintuc/page/${i + 1}`}
                className={`px-3 py-1 border rounded ${
                  i + 1 === pageNumber ? "bg-blue-500 text-white" : ""
                }`}
              >
                {i + 1}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
