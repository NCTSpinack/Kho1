import { redirect } from "next/navigation";

export default function Page() {
  // Tự động redirect sang trang 1
  redirect("/tintuc/page/1");
}