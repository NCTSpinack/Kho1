import { db } from "./db";

export async function getProductBySlug(slug: string) {
  const product = await db.lop_oto.findFirst({
    where: { slug },
    include: {
      anh_lop: true,
      gia_lop: true,
      loai_lop: true,
      thuong_hieu: true,
      thong_so_lop: true,
      kich_thuoc: true,
    },
    orderBy: {
      ngay_cap_nhat: "desc",
    },
  });

  if (!product) return null;

  const gia = product.gia_lop[0];

  return {
    id: product.id,
    ten_lop: product.ten_lop,
    xuat_xu: product.xuat_xu,
    trang_thai: product.trang_thai,
    anh_dai_dien: product.anh_dai_dien,
    thuong_hieu: product.thuong_hieu?.ten_thuong_hieu,
    loai_lop: product.loai_lop?.ten_loai_lop,
    kich_thuoc: product.kich_thuoc?.ma_kich_thuoc,
    slug: product.slug,
    price: gia?.gia_ban
      ? `${gia.gia_ban.toNumber().toLocaleString("vi-VN")} VNĐ`
      : "Chưa có giá",
    images: product.anh_lop.map((img) => img.url_anh),
    mo_ta: product.mo_ta_chi_tiet,
  };
}
