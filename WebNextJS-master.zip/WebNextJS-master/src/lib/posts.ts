// lib/posts.ts

import prisma from "./prisma";

export async function getPostsByPage(page: number, perPage: number) {
  const skip = (page - 1) * perPage;

  // Lấy bài viết từ bảng TintucLopoto, phân trang
  const posts = await prisma.tintucLopoto.findMany({
    skip,
    take: perPage,
    where: { trang_thai: true },
    orderBy: { ngay_dang: 'desc' },
    select: {
      id: true,
      tieu_de: true,
      tom_tat: true,
      ngay_dang: true,
      slug: true,
      hinh_anh: true,
    },
  });

  // Tính tổng số bài viết
  const total = await prisma.tintucLopoto.count({
    where: { trang_thai: true },
  });

  const totalPages = Math.ceil(total / perPage);

  // Chuẩn hóa dữ liệu trả về giống mẫu
  return {
    posts: posts.map(post => ({
      id: post.id,
      title: post.tieu_de,
      excerpt: post.tom_tat ?? '',
      createdAt: post.ngay_dang,
      slug: post.slug,
      images: post.hinh_anh,
    })),
    total,
    totalPages,
  };
}
export async function getPostBySlug(slug: string) {
  const res = await prisma.tintucLopoto.findUnique({
    where: { slug },
    select: {
      id: true,
      tieu_de: true,
      noi_dung: true,
      ngay_dang: true,
      slug: true,
      hinh_anh: true,
    },
  });

  if (!res) return null;

  return {
    id: res.id,
    title: res.tieu_de,
    content: res.noi_dung ?? '',
    createdAt: res.ngay_dang,
    slug: res.slug,
    images: res.hinh_anh,
  };
}
