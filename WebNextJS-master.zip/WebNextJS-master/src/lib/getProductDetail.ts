import { db } from "./db";
type SpecItem = {
  label: string;
  value: string | number | null;
};
export async function getProductDetail(slug: string) {
  const p = await db.san_pham.findFirst({
    where: { slug },
    include: {
      hinh_anh_san_pham: true,
      thong_so_ac_quy: {
        select: {
          thuong_hieu: true,
          dung_luong: true,
          dien_ap: true,
          xuat_xu: true,
          loai_ac_quy: true,
        },
      },
      thong_so_dau:{
        select:{
          thuong_hieu: true,
          xuat_xu: true,
          dung_tich: true,
          do_nhot: true,
          loai_dau: true
        }
      },
      thong_so_lop:{
        include:{
          kich_thuoc: true,
          loai_lop: true,
          thuong_hieu: true
        }
      }
      

    },
    orderBy: {
      ngay_cap_nhat: "desc",
    },
  });

  if (!p) return null;
  console.log("p:",p)
  let specs: SpecItem[] = [];
    if (p.thong_so_ac_quy?.length) {
    specs = [
      { label: "Thương hiệu", value: p.thong_so_ac_quy[0].thuong_hieu },
      { label: "Dung lượng", value: p.thong_so_ac_quy[0].dung_luong },
      { label: "Điện áp", value: p.thong_so_ac_quy[0].dien_ap },
      { label: "Xuất xứ", value: p.thong_so_ac_quy[0].xuat_xu },
      { label: "Loại ắc quy", value: p.thong_so_ac_quy[0].loai_ac_quy }

    ];
  } else if (p.thong_so_dau?.length) {
    specs = [
      { label: "Thương hiệu", value: p.thong_so_dau[0].thuong_hieu },
      { label: "Xuất xứ", value: p.thong_so_dau[0].xuat_xu },
      { label: "Dung tích", value: p.thong_so_dau[0].dung_tich },
      { label: "Độ nhớt", value: p.thong_so_dau[0].do_nhot },
      { label: "Loại dầu", value: p.thong_so_dau[0].loai_dau }

    ];
  }
  else if (p.thong_so_lop?.length){
    specs = [
      { label: "Thương hiệu", value: p.thong_so_lop[0].thuong_hieu?.ten_thuong_hieu || ""},
      { label: "Loại lốp", value: p.thong_so_lop[0].loai_lop?.ten_loai_lop || ""},
      { label: "Kích thước", value: p.thong_so_lop[0].kich_thuoc?.ma_kich_thuoc || ""},
      { label: "Xuất xứ", value: "Thái lan"},
      { label: "Hoa lốp", value: "Primacy 4"},
      { label: "Sản xuất", value: "2022"},



      

    ];
  }

   return {
    ...p,
    specs, 
  };
    
}
