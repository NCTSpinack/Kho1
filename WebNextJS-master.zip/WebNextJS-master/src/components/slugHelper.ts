import slugify from "slugify";

export function toSeoSlug(str: string) {
  return slugify(
    str
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .replace(/\//g, "-"),
    {
    lower: true,
    strict: true,
    locale: "vi",
  });
}