'use client';

import { useState } from 'react';

export default function AnhDaiDienPopup({
  imageUrls,
  onSelect,
}: {
  imageUrls: string[];
  onSelect?: (url: string) => void; // 👈 Thêm callback truyền ảnh ra ngoài
}) {
  const [showPopup, setShowPopup] = useState(false);
  const [selectedUrl, setSelectedUrl] = useState<string | null>(null);

  const handleSelectImage = (url: string) => {
    setSelectedUrl(url);
    setShowPopup(false);
    onSelect?.(url); // 👈 Gửi ảnh ra ngoài (nếu có callback)
  };

  return (
    <div className="mt-5">
      <label className="block font-semibold mb-2">Đặt ảnh đại diện:</label>

      {selectedUrl ? (
        <img
          src={selectedUrl}
          alt="Ảnh đại diện"
          className="w-32 h-32 object-cover rounded border mb-4"
        />
      ) : (
        <div className="w-32 h-32 bg-gray-200 flex items-center justify-center rounded mb-4">
          Chưa chọn ảnh
        </div>
      )}

      <button
        type="button"
        onClick={() => setShowPopup(true)}
        className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-blue-800"
      >
        Chọn ảnh đại diện
      </button>

      {showPopup && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg max-w-3xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">Chọn ảnh đại diện</h2>
              <button
                className="text-red-500 hover:text-red-700"
                onClick={() => setShowPopup(false)}
              >
                Đóng
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {imageUrls.map((url, index) => (
                <div
                  key={index}
                  className="border rounded overflow-hidden cursor-pointer hover:border-blue-500"
                  onClick={() => handleSelectImage(url)}
                >
                  <img
                    src={url}
                    alt={`Ảnh ${index + 1}`}
                    className="w-full h-40 object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
