'use client';

import { useEffect, useState } from 'react';
import createDOMPurify from 'dompurify';

// tạo DOMPurify từ window (chỉ hoạt động trên client)
export default function MoTaSanPham({ html }: { html: string }) {
  const [sanitizedHTML, setSanitizedHTML] = useState('');

  useEffect(() => {
    const DOMPurify = createDOMPurify(window);
    setSanitizedHTML(DOMPurify.sanitize(html));
  }, [html]);

  return <div dangerouslySetInnerHTML={{ __html: sanitizedHTML }} />;
}
