"use client";
import { useState, useRef, useEffect } from "react";
import Image from "next/image";
export default function ImageGalleryWithModal({ image }: { image: string[] }) {
  if (!image || !Array.isArray(image) || image.length === 0) return null;
  const [isOpen, setIsOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const overlayRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;
  const handleOpen = (index: number) => {
    setCurrentIndex(index);
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === overlayRef.current) {
      handleClose();
    }
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? image.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === image.length - 1 ? 0 : prev + 1));
  };
  console.log("image", image);
  const currentImage = image[currentIndex];
  return (
    <>
      <div className="w-full max-w-4xl mx-auto aspect-auto rounded-md shadow overflow-hidden border border-gray-300 bg-white p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {image.map((src: string, index: number) => (
            <Image
              key={index}
              src={src}
              alt={`Ảnh ${index + 1}`}
              width={400}
              height={300}
              onClick={() => handleOpen(index)}
              className="rounded object-contain border"
              sizes="(max-width: 768px) 100vw, 800px"
              
            />
          ))}
        </div>
      </div>
      {isOpen && (
        <div
          ref={overlayRef}
          onClick={handleOverlayClick}
          className="fixed inset-0 bg-black bg-opacity-80 flex justify-center items-center z-50"
        >
          <div className="relative p-4 flex flex-col items-center">
            {/* Nút đóng */}
            <button
              onClick={handleClose}
              className="absolute top-2 right-4 text-white text-4xl font-bold hover:text-red-400 z-10"
            >
              &times;
            </button>

            {/* Ảnh lớn */}
            <Image
              src={currentImage}
              alt={`Ảnh ${currentIndex + 1}`}
              width={1000}
              height={700}
              className="max-w-[90vw] max-h-[80vh] object-contain"
            />

            {/* Điều khiển slide */}
            <div className="flex justify-between items-center w-full mt-4 px-8">
              <button
                onClick={handlePrev}
                className="text-white bg-gray-700 hover:bg-gray-500 px-4 py-2 rounded"
              >
                ⬅ Trước
              </button>
              <a
                href={currentImage}
                download
                className="text-white bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded"
              >
                ⬇ Tải ảnh
              </a>
              <button
                onClick={handleNext}
                className="text-white bg-gray-700 hover:bg-gray-500 px-4 py-2 rounded"
              >
                Tiếp ➡
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
