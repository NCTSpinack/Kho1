"use client"; // Nếu dùng trong App Router

import React from "react";
import { Editor } from "@tinymce/tinymce-react";

export default function MyEditor({
  value,
  onChange,
}: {
  value: string;
  onChange: (content: string) => void;
}) {
  return (
    <Editor
      apiKey="127ulu2czqfzsikksap8fullt3z3sbnl0lm893gl5u9p9wk0" // có thể để trống nếu dùng localhost
      value={value}
      onEditorChange={onChange}
      init={{
        height: 400,
        menubar: false,
        plugins: [
          "advlist", "autolink", "lists", "link", "image", "charmap", "preview",
          "anchor", "searchreplace", "visualblocks", "code", "fullscreen",
          "insertdatetime", "media", "table", "code", "help", "wordcount"
        ],
        toolbar:
          "undo redo | formatselect | bold italic backcolor | \
           alignleft aligncenter alignright alignjustify | \
           bullist numlist outdent indent | removeformat | help"
      }}
    />
  );
}
