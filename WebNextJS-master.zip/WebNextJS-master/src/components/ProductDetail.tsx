"use client";

import Image from "next/image";
import { useState } from "react";
import ImageGalleryWithModal from "@/components/ImageGalleryWithModal";
import MoTaSanPham from "@/components/MoTaSanPham";
import Sidebar_Categories from "@/app/component/Sidebar_Categories";
type Spec = { label: string; value: string };
export default function ProductDetaiAll({ p }: { p: any }) {
  const [selectedImage, setSelectedImage] = useState<string>(
    p.anh_dai_dien ?? ""
  );
  console.log("product:", p);
  console.log(selectedImage);

  return (
    <>
      <div className="container mx-auto w-11/12 mb-10 rounded-lg">
        <div className="grid md:grid-cols-4 gap-6 font-medium rounded-lg shadow-sm bg-white p-6">
          <aside className="hidden md:block md:col-span-1 border border-gray-200 rounded-lg">
            <Sidebar_Categories />
          </aside>

          <main className="col-span-4 md:col-span-3 border border-gray-200 rounded-lg p-4 sm:p-8 bg-white">
            <header className="text-center mb-10">
              <h1 className="text-2xl font-semibold text-gray-950 uppercase ">
                {p.ten_san_pham}
              </h1>
              <hr className="border-gray-500 w-50 mx-auto mt-2" />
            </header>

            <article className="max-w-6xl mx-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-8 items-start bg-white mt-10">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative overflow-hidden rounded-lg w-full max-w-md">
                  <Image
                    src={selectedImage}
                    alt={p.ten_san_pham}
                    width={500}
                    height={500}
                    className="rounded-lg shadow-md object-contain"
                    priority
                  />
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {Array.isArray(p.hinh_anh_san_pham) && p.hinh_anh_san_pham.length > 0 ? (
                    p.hinh_anh_san_pham.map((item: any, i: number) => (
                      <Image
                        key={item.id ?? i}
                        src={item.url_anh}
                        alt={`Ảnh ${i + 1}`}
                        width={80}
                        height={80}
                        onClick={() => setSelectedImage(item.url_anh)}
                        className={`rounded border border-gray-300 cursor-pointer hover:scale-105 transition ${
                          selectedImage === item.url_anh ? "ring-2 ring-blue-500" : ""
                        }`}
                      />
                    ))
                  ) : (
                    <p>Không có ảnh</p>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <h1 className="text-2xl font-bold text-gray-800">{p.ten_san_pham}</h1>
                <p className="text-base">
                  <span className="font-semibold text-gray-700">
                    Giá sản phẩm:
                  </span>
                  <span className="text-red-600 font-bold ml-2">Liên hệ</span>
                </p>

                <ul className="list-disc list-inside text-gray-700 space-y-3 text-sm">
                  {p.specs?.map((spec: Spec, index: number) => (
                    <li key={index}>
                      <strong>{spec.label}:</strong> {spec.value}
                    </li>
                  ))}
                </ul>

                <div className="flex gap-4 mt-4">
                  <a
                    href="https:zalo.me/0967074459"
                    target="_blank"
                    className="bg-green-600 hover:bg-green-700 transition text-white px-6 py-2 rounded shadow"
                  >
                    Chat Zalo
                  </a>
                  <a
                    href="tel:0967074459"
                    className="bg-blue-900 hover:bg-blue-800 transition text-white px-6 py-2 rounded shadow"
                  >
                    Gọi điện
                  </a>
                </div>
              </div>
            </article>

            <article className="max-w-4xl mx-auto">
              <div className="border border-gray-300 rounded-lg bg-gray-50 p-6 mb-8 shadow-sm">
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-blue-800 mb-2">
                    Lốp ô tô Cảnh Thạch
                  </h2>
                  <p className="italic text-blue-800">
                    “Mua bán trao đổi lốp ô tô cũ đã qua sử dụng tại Hà Nội”
                  </p>
                </div>

                <ul className="italic text-gray-800 space-y-4 text-base">
                  <li>
                    <span className="font-medium text-pink-600">
                      📘 FACEBOOK:
                    </span>
                    Lốp ô tô Cảnh Thạch
                  </li>
                  <li>
                    <span className="font-medium text-pink-600">
                      📍 ĐỊA CHỈ:
                    </span>
                    Số 7, Đường 70, Yên Xá, Tân Triều, Thanh Trì, HN
                  </li>
                  <li>
                    ☎️ HOTLINE:
                    <span className="font-bold text-pink-600">0349566377</span>
                  </li>
                </ul>
              </div>

              {p.mo_ta_chi_tiet && (
                <div className="border border-gray-300 rounded-lg bg-gray-50 p-6 mb-8 shadow-sm">
                  <h2 className="text-3xl font-bold text-blue-800 mb-6 text-center">
                    {p.ten_san_pham}
                  </h2>
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Giới thiệu:
                  </h3>
                  <MoTaSanPham html={p.mo_ta_chi_tiet} />
                </div>
              )}

              {Array.isArray(p?.hinh_anh_san_pham) && p.hinh_anh_san_pham.length > 0 && (
                <ImageGalleryWithModal image={p.hinh_anh_san_pham.map((item: any) => item.url_anh)} />
              )}
            </article>
          </main>
        </div>
      </div>
    </>
  );
}
